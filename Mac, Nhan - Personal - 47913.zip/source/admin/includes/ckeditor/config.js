﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	config.skin='office2003';
	
config.filebrowserBrowseUrl = 'includes/ckfinder/ckfinder.html';

config.filebrowserImageBrowseUrl = 'includes/ckfinder/ckfinder.html?type=Images';

config.filebrowserUploadUrl = 'includes/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';

config.filebrowserImageUploadUrl = 'includes/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';


};

