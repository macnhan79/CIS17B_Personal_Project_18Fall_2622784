1. MySql Connection information in includes/connection.php
2. Run Database.sql
3. admin url: http://yourwebside/admin (example: http://localhost/admin)
4. Account
					Username		Password
-----------------------------------------------------					
Normal user			abc				123456
admin				admin			123456
-----------------------------------------------------