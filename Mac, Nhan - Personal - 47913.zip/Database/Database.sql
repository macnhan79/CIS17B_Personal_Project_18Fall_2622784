/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50560
Source Host           : localhost:3306
Source Database       : test1

Target Server Type    : MYSQL
Target Server Version : 50560
File Encoding         : 65001

Date: 2018-12-13 00:43:43
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `chitiethoadon`
-- ----------------------------
DROP TABLE IF EXISTS `chitiethoadon`;
CREATE TABLE `chitiethoadon` (
  `idChiTiet` int(4) NOT NULL AUTO_INCREMENT,
  `idDH` int(4) NOT NULL,
  `idSP` varchar(12) NOT NULL,
  `Gia` int(4) NOT NULL,
  `SoLuong` int(4) NOT NULL,
  PRIMARY KEY (`idChiTiet`)
) ENGINE=MyISAM AUTO_INCREMENT=258 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chitiethoadon
-- ----------------------------
INSERT INTO chitiethoadon VALUES ('257', '109', 'sony1', '123', '1');

-- ----------------------------
-- Table structure for `chitietsanpham`
-- ----------------------------
DROP TABLE IF EXISTS `chitietsanpham`;
CREATE TABLE `chitietsanpham` (
  `idSP` varchar(12) NOT NULL,
  `cpu` varchar(255) NOT NULL,
  `mainboard` varchar(255) NOT NULL,
  `ram` varchar(255) NOT NULL,
  `harddisk` varchar(255) NOT NULL,
  `display` varchar(255) NOT NULL,
  `gpu` varchar(255) NOT NULL,
  `sound` varchar(255) NOT NULL,
  `bluray` varchar(255) NOT NULL,
  `network` varchar(255) NOT NULL,
  `camera` varchar(255) NOT NULL,
  `pin` varchar(255) NOT NULL,
  `os` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`idSP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chitietsanpham
-- ----------------------------
INSERT INTO chitietsanpham VALUES ('Dell2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipod1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('Acer3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('Dell1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('asus6', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('o1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('s2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('asus5', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('s1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('y', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('t', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('t1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ss3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('l1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('n4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('n3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('n2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('HTC 2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('HTC 1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('n1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ss2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('LG 1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('xo1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('acatel', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('acer2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ss1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('Asus4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('asus3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('sony 1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('iphone 1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('D-Com1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('asus1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '<p>\r\n	-</p>\r\n');
INSERT INTO chitietsanpham VALUES ('Acer1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('Asus2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma8', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma7', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma6', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma5', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ma1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('iphone 2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipod3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipod2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipad6', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ss4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipad5', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipad4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipad3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipad2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p27', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipad1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p26', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p25', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p24', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p23', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p22', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p21', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p20', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p19', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p17', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p16', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p15', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p14', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p13', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p12', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p11', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p10', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p9', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p8', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p7', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p6', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('Acer4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p5', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('l2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('p2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('acer5', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('qq', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('m', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ipad7', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ktd1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ktd2', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ktd3', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ktd4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('ktd5', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('laptop01', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '<p style=\"text-align: center;\">\r\n	-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>\r\n<p style=\"text-align: center;\">\r\n	<img alt=\"\" src=\"/myproject/images/images/44ff7861251c45_img.jpg\" style=\"width: 450px; height: 338px;\" /></p>\r\n');
INSERT INTO chitietsanpham VALUES ('abc', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
INSERT INTO chitietsanpham VALUES ('NT001', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '<p>\r\n	-aaaaaaaaaaaaaaaaa</p>\r\n');
INSERT INTO chitietsanpham VALUES ('AAA', '-', '-', '-8G', '-32G', '-9in', '-', '-', '-', '-', '-', '-', '-', '-', '<p>\r\n	aaaaaaaaaaaaaaa</p>\r\n');

-- ----------------------------
-- Table structure for `chungloaisanpham`
-- ----------------------------
DROP TABLE IF EXISTS `chungloaisanpham`;
CREATE TABLE `chungloaisanpham` (
  `idCL` int(4) NOT NULL AUTO_INCREMENT,
  `idLoaiSP` int(4) NOT NULL,
  `tenCL` varchar(100) NOT NULL,
  `AnHien` int(1) NOT NULL,
  PRIMARY KEY (`idCL`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chungloaisanpham
-- ----------------------------
INSERT INTO chungloaisanpham VALUES ('1', '1', 'IOS', '1');
INSERT INTO chungloaisanpham VALUES ('2', '1', 'Touch', '1');
INSERT INTO chungloaisanpham VALUES ('3', '1', 'Android', '1');
INSERT INTO chungloaisanpham VALUES ('4', '2', 'Window', '1');
INSERT INTO chungloaisanpham VALUES ('5', '2', 'LapTop', '1');
INSERT INTO chungloaisanpham VALUES ('6', '2', 'Netbook', '1');
INSERT INTO chungloaisanpham VALUES ('7', '2', 'Notebook', '1');
INSERT INTO chungloaisanpham VALUES ('8', '2', 'Ultrabook', '1');
INSERT INTO chungloaisanpham VALUES ('29', '1', 'Qwerty', '1');
INSERT INTO chungloaisanpham VALUES ('10', '3', 'Asus', '1');
INSERT INTO chungloaisanpham VALUES ('11', '3', 'Apple', '1');
INSERT INTO chungloaisanpham VALUES ('12', '3', 'Samsung', '1');
INSERT INTO chungloaisanpham VALUES ('13', '3', 'Acer', '1');
INSERT INTO chungloaisanpham VALUES ('14', '4', 'Mobile Accessories', '1');
INSERT INTO chungloaisanpham VALUES ('15', '4', 'Computer Accessories', '1');
INSERT INTO chungloaisanpham VALUES ('16', '4', 'Tablet Accessories', '1');

-- ----------------------------
-- Table structure for `gopy`
-- ----------------------------
DROP TABLE IF EXISTS `gopy`;
CREATE TABLE `gopy` (
  `idGopY` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `ThoiDiemGopY` date NOT NULL,
  `NoiDung` text NOT NULL,
  `idSP` varchar(12) NOT NULL,
  PRIMARY KEY (`idGopY`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of gopy
-- ----------------------------
INSERT INTO gopy VALUES ('61', 'admin', '2012-11-06', 'aaaaaaaaaaaaaaaaaaaa', '2');
INSERT INTO gopy VALUES ('62', 'admin', '2012-11-06', 'aaaaaaaaaaaaaaaaaaaa', '2');
INSERT INTO gopy VALUES ('69', 'admin', '2012-11-14', 'dfkbkdjfkb', 'sony1');
INSERT INTO gopy VALUES ('71', 'admin', '2012-11-14', ' Samsum Nokia Honda', 'NT001');
INSERT INTO gopy VALUES ('73', 'admin', '2018-12-13', 'gserg', 'asus5');

-- ----------------------------
-- Table structure for `hoadon`
-- ----------------------------
DROP TABLE IF EXISTS `hoadon`;
CREATE TABLE `hoadon` (
  `idDH` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `ThoiDiemDatHang` date NOT NULL,
  `TinhTrang` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idDH`)
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hoadon
-- ----------------------------
INSERT INTO hoadon VALUES ('108', 'abcd', '2018-12-13', '0');
INSERT INTO hoadon VALUES ('109', 'abcd', '2018-12-13', '1');

-- ----------------------------
-- Table structure for `loaisanpham`
-- ----------------------------
DROP TABLE IF EXISTS `loaisanpham`;
CREATE TABLE `loaisanpham` (
  `idLoaiSP` int(4) NOT NULL AUTO_INCREMENT,
  `tenLoaiSP` varchar(100) NOT NULL,
  `AnHien` int(1) NOT NULL,
  PRIMARY KEY (`idLoaiSP`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of loaisanpham
-- ----------------------------
INSERT INTO loaisanpham VALUES ('1', 'Mobile', '1');
INSERT INTO loaisanpham VALUES ('2', 'Computer', '1');
INSERT INTO loaisanpham VALUES ('3', 'Tablet', '1');
INSERT INTO loaisanpham VALUES ('4', 'Accessories', '1');

-- ----------------------------
-- Table structure for `sanpham`
-- ----------------------------
DROP TABLE IF EXISTS `sanpham`;
CREATE TABLE `sanpham` (
  `idSP` varchar(12) NOT NULL,
  `idLoai` int(4) NOT NULL,
  `idCL` int(4) NOT NULL,
  `TenSP` varchar(100) NOT NULL,
  `NgayCapNhat` date NOT NULL,
  `Gia` int(4) NOT NULL,
  `UrlHinh` varchar(255) NOT NULL,
  `SoLuongTonKho` int(4) NOT NULL,
  `GhiChu` varchar(255) NOT NULL,
  `AnHien` int(1) NOT NULL,
  `warranty` varchar(255) NOT NULL,
  PRIMARY KEY (`idSP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sanpham
-- ----------------------------
INSERT INTO sanpham VALUES ('sony1', '1', '2', 'Sony Xperia Ion', '2012-11-04', '123', 'images/48d46f71-ebad-45eb-ae76-071169cbb83a.jpg', '7', 'aaaaaaaaa', '1', '2 ');
INSERT INTO sanpham VALUES ('asus1', '3', '10', 'Asus Tab X500', '2012-11-04', '456', 'images/44ff7861251c45.img.jpg', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('Acer1', '3', '10', 'Acer', '2012-11-04', '783', 'images/474_dap-hop-may-tinh-bang-Acer-Iconia-Tab-W500-tai-The.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('Asus2', '3', '11', 'Asus', '2012-11-04', '78374', 'images/1000505995_Asus-30.jpg', '0', '', '1', '2 ');
INSERT INTO sanpham VALUES ('asus3', '3', '13', 'asus', '2012-11-04', '788', 'images/asus_eee_pad_ces_2012_large_verge_medium_landscape.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('Asus4', '3', '12', 'Asus', '2012-11-04', '258', 'images/1000505995_Asus-30.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('ss1', '1', '2', 'sam sung', '2012-11-04', '282', 'images/1.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('acer2', '2', '5', 'Acer', '2012-11-04', '288', 'images/3.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('acatel', '1', '1', 'acatel ot606', '2012-11-04', '852', 'images/23935_dien-thoai-di-dong-acatel-ot606-nau.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('xo1', '1', '29', 'xo', '2012-11-04', '223', 'images/40200368_194794sm.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('LG1', '1', '2', 'LG optimusL3E400', '2012-11-04', '822', 'images/1342657946-dien-thoai-di-dong-lg-optimusL3E400-dienmay.com-1.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('ss2', '1', '1', 'sam sung c3312', '2012-11-04', '863', 'images/1342876904-dien-thoai-did-dong-samsung-c3312-dienmay.com-1.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('n1', '1', '1', 'nokia 1280', '2012-11-04', '812', 'images/1349945310_2.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('HTC1', '1', '2', 'HTC desire', '2012-11-04', '225', 'images/big_21374_htc-desire-w.jpg', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('HTC2', '1', '1', 'HTC', '2012-11-04', '622', 'images/ImageHandler.jpg', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('n2', '1', '2', 'nokia 5800', '2012-11-04', '442', 'images/chinh@2011112683626459_0.jpg', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('n3', '1', '2', 'nokia n9', '2012-11-04', '441', 'images/image012-500x500.jpg', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('n4', '1', '1', 'nokia n95', '2012-11-04', '2111', 'images/large_05_2012_b597aa2243379bdfe184ac498832b713.gif', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('l1', '1', '1', 'large', '2012-11-04', '2255', 'images/large_06_2011_643fc922e94691d0d7d9f2334f4175b3.gif', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('ss3', '1', '1', 'sam sung s5233', '2012-11-04', '5500', 'images/large_06_2011_3837f069b203073628d43a23c0735acf.gif', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('t1', '1', '2', 'hearphone', '2012-11-04', '8522', 'images/1000009234_chu2.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('t', '1', '1', 'LG', '2012-11-04', '6224', 'images/large_06_2011_5910c25452b382f019c8e905d68813f7.gif', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('y', '1', '1', 'nokia', '2012-11-04', '4422', 'images/nokia1.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('p1', '1', '2', 'pin', '2012-11-04', '580', 'images/1275034771_96474566_1-Hinh-anh-ca--PH-KIN-dIN-THOI-GIa-R-daT-1275034771.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('s1', '1', '2', 'abc', '2012-11-04', '8572', 'images/1336359353_1332835110_75161888-127552_iphone1.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('asus5', '2', '4', 'asus', '2012-11-04', '722', 'images/1000507939_Asus_11.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('s2', '1', '2', 'gteg', '2012-11-04', '7563', 'images/2009052056_3.jpg', '2', '', '1', '2');
INSERT INTO sanpham VALUES ('o1', '1', '2', 'rthr', '2012-11-04', '8785', 'images/1547018522_IMG_2105.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('asus6', '2', '4', 'Asus', '2012-11-04', '5500', 'images/1000508764_Asus_Transformer_1.jpg', '2', '', '1', '2 ');
INSERT INTO sanpham VALUES ('Dell1', '2', '4', 'Dell', '2012-11-04', '343', 'images/1290600410_141144664_1-Hinh-anh-ca--Ban-Laptop-c-tai-da-Nng-Can-ban-Laptop-c-tai-da-Nng-Cong-ty-ban-Laptop-c-tai-da-N-1290600410.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('Acer3', '2', '4', 'Acer', '2012-11-04', '45', 'images/Acer-ICONIA-Tab-W500.jpg', '2', 'ưe', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipod1', '4', '15', 'ipod', '2012-11-04', '452', 'images/45254889-mp3.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('Acer4', '2', '4', 'Acer', '2012-11-04', '45', 'images/Acer-ICONIA-Tab-W500.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('Dell2', '2', '4', 'Dell', '2012-11-04', '100', 'images/Dell-Latitude-D620.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('m', '2', '4', 'l', '2012-11-04', '100', 'images/a04.png', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('qq', '2', '5', '', '2012-11-04', '100', 'images/1292553069_147396078_3-cty-may-van-phong-tuan-hai-chuyen-phan-phoi-linh-kien-va-phu-kien-laptop-May-tinh-Phan-cung.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('acer5', '2', '4', 'acer', '2012-11-04', '100', 'images/laptop-aspire-acer.jpg', '2', 'qư', '1', '2 năm');
INSERT INTO sanpham VALUES ('p2', '2', '5', 'speaker', '2012-11-04', '100', 'images/03.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p3', '2', '5', 'speaker', '2012-11-04', '100', 'images/ban-laptop-nhua.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p4', '2', '4', 'speaker', '2012-11-04', '100', 'images/1334884645_297959739_1-Hinh-anh-ca--Sac-pin-va-phu-kien-laptop-gia-tot-tai-Hai-Duong.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('l2', '2', '6', 'speaker', '2012-11-04', '100', 'images/69324a49e1b5916dae6aac5b068f9da0.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p5', '2', '5', 'speaker', '2012-11-04', '100', 'images/l.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p6', '2', '6', 'speaker', '2012-11-04', '100', 'images/05092007235720484633246334404843750.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p7', '2', '6', 'speaker', '2012-11-04', '100', 'images/15143876_5581.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p8', '2', '6', 'speaker', '2012-11-04', '100', 'images/1286214849_loa-rap-hat-tai-nha.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p9', '2', '6', 'speaker', '2012-11-04', '100', 'images/B55.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p10', '2', '6', 'speaker', '2012-11-04', '100', 'images/b40_l_2990.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p11', '2', '6', 'speaker', '2012-11-04', '100', 'images/20714629_images1355384_loa.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p12', '2', '6', 'speaker', '2012-11-04', '100', 'images/1286213262_loa-5-1-loa-may-tinh-loa-vi-tinh.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p13', '2', '6', 'speaker', '2012-11-04', '100', 'images/1278469172_103667575_3-Bo-suu-tap-loa-vi-tinh-dng-cap-do-dien-tu.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p14', '2', '6', 'speaker', '2012-11-04', '265', 'images/1278469172_103667575_2-Bo-suu-tap-loa-vi-tinh-dng-cap-Ha-Noi.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p15', '2', '6', 'casio-exilim', '2012-11-04', '265', 'images/1000397859_E2.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p16', '2', '6', 'speaker', '2012-11-04', '265', 'images/1278469172_103667575_1-Hinh-anh-ca--Bo-suu-tap-loa-vi-tinh-dng-cap.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p17', '2', '6', 'speaker', '2012-11-04', '265', 'images/1000015135_al1.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p19', '2', '6', 'speaker', '2012-11-04', '265', 'images/B1cvz.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p20', '2', '6', 'speaker', '2012-11-04', '265', 'images/1260362023.img.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p21', '2', '6', 'LOA', '2012-11-04', '265', 'images/chdhy1242708021.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p22', '2', '6', 'loa E3300', '2012-11-04', '265', 'images/E3300.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p23', '2', '6', 'loa e3350', '2012-11-04', '265', 'images/e3350---black.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p24', '2', '6', 'loa  soundmax', '2012-11-04', '265', 'images/loa_vi_tinh_soundmax_b91.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p25', '2', '8', 'USB 8G', '2012-11-04', '265', 'images/1269504664_82812414_1-Hinh-anh-ca--USB-3G-ket-noi-internet-ma-mi-MC950D-toc-do-n-dinh-Gia-tot-day.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p26', '2', '8', 'USB 16G', '2012-11-04', '265', 'images/1274331524_64483315_1-Hinh-anh-ca--USB-3G-Mang-khong-day-hon-ca-co-day-1274331524.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipad1', '3', '12', 'Acer W700', '2012-11-04', '265', 'images/1321421514_Acer_W700_2.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('p27', '2', '8', 'MP3', '2012-11-04', '265', 'images/opf1305547989.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipad2', '3', '13', 'Asus', '2012-11-04', '265', 'images/1000507939_Asus_12.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipad3', '3', '12', 'Acer', '2012-11-04', '265', 'images/110530113323-254-701.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipad4', '3', '12', 'Asus', '2012-11-04', '1001', 'images/1100174638.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipad5', '3', '11', 'ipad 2 32G', '2012-11-04', '1001', 'images/may-tinh-bang-apple-ipad2-dienmay.com-6.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ss4', '3', '10', 'sam sung C5532', '2012-11-04', '1001', 'images/41_201048154439_22.jpg', '2', 'aaaaaâ', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipad6', '3', '10', 'ipad 2 16G', '2012-11-04', '1001', 'images/may-tinh-bang-ipad-2-2.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipod2', '4', '15', 'MP3', '2012-11-04', '1001', 'images/1277439587-hi-techiipod-nano-5.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipod3', '4', '15', 'mp3', '2012-11-04', '1001', 'images/1302593444_153413703_1-Hinh-anh-ca--May-nghe-nhac-mp3-mp4-ipod-d-loai-mp3-phong-cach-thi-trang-tre-trung-nang-dong-gia-t.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('iphone2', '1', '1', 'iphone 3 8G', '2012-11-04', '1001', 'images/didong1.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma1', '4', '14', 'asgsegesg', '2012-11-04', '1001', 'images/cach-bao-quan-may-anh-so-dung-cach-813201211912am.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma2', '4', '14', 'asgsegesg', '2012-11-04', '1001', 'images/A1100-IS.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma3', '4', '14', 'canon', '2012-11-04', '1001', 'images/canon.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma4', '4', '14', 'casio-exilim', '2012-11-04', '1001', 'images/casio-exilim.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma5', '4', '14', 'casio-exilim', '2012-11-04', '1001', 'images/cat_96.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma6', '4', '14', 'casio-exilim', '2012-11-04', '1001', 'images/img-1229677698-1.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma7', '4', '14', 'casio-exilim', '2012-11-04', '1001', 'images/lky1320876666.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ma8', '4', '14', 'casio-exilim', '2012-11-04', '1001', 'images/medium_cnj1332440385.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ipad7', '4', '16', 'acer-iconia', '2012-11-04', '1001', 'images/1319561366_bang.vn_may-tinh-bang-acer-iconia-6120-14-inch-d-13058562761023645664_574_0.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ktd1', '4', '14', 'casio-exilim', '2012-11-04', '1001', 'images/b4-2.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ktd2', '4', '16', 'casio-exilim', '2012-11-04', '1001', 'images/cat_248.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ktd3', '4', '16', 'casio-exilim', '2012-11-04', '1001', 'images/dvt_1347525996.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ktd4', '4', '16', 'product_s2273', '2012-11-04', '1001', 'images/product_s2273.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('ktd5', '4', '16', 'Samsung-Table', '2012-11-04', '1001', 'images/Samsung-Tablet-1.jpg', '2', '', '1', '2 năm');
INSERT INTO sanpham VALUES ('laptop01', '2', '5', 'Acer ICONIA Tab W500', '2012-11-06', '1001', 'images/Acer-ICONIA-Tab-W500.jpg', '0', 'fdbgdfb', '1', '2 năm');

-- ----------------------------
-- Table structure for `taikhoan`
-- ----------------------------
DROP TABLE IF EXISTS `taikhoan`;
CREATE TABLE `taikhoan` (
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `idBank` varchar(100) DEFAULT NULL,
  `admin` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of taikhoan
-- ----------------------------
INSERT INTO taikhoan VALUES ('admin', 'e10adc3949ba59abbe56e057f20f883e', 'administrator@administrator.com', '939320295', 'Mac Thanh Nhan', 'tran viet chau', '', '1');
INSERT INTO taikhoan VALUES ('simemon', 'd41d8cd98f00b204e9800998ecf8427e', 'lovetobelovesbyyou_381@yahoo.com.vn', '1698714949', 'nguyễn thanh quí', 'ádasc', null, '0');
INSERT INTO taikhoan VALUES ('admin11', 'e10adc3949ba59abbe56e057f20f883e', '123456@hjkh.com', '123456', '123456', '123456', null, '0');
INSERT INTO taikhoan VALUES ('aaaaaaaaaa', '45e4812014d83dde5666ebdf5a8ed1ed', 'gjkhsjgk@yahoo.com', '2147483647', 'aaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaa', null, '2');
INSERT INTO taikhoan VALUES ('rrrrrrrrrr', '66ba13e5474d241e80f7a12ed434645d', 'kjghsjk@ysghkl.com', '322158554', 'rrrrrrrrrr', 'rrrrrrrrrr', null, '2');
INSERT INTO taikhoan VALUES ('abcd', 'e10adc3949ba59abbe56e057f20f883e', 'boy@gmail.com', '45645', 'fbdfb', 'gre', null, '0');
